package AdminServs;

public interface AdminInfo {
	
	public AdminUP getAdminUP(String username, String password);
}
